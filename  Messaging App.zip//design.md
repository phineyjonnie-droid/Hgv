# Messaging App Design Style Guide

## Design Philosophy

### Visual Language
**Modern Minimalism with Depth**: Inspired by Telegram's "Liquid Glass" design philosophy, our interface combines clean minimalism with subtle depth and translucency effects. The design emphasizes clarity, speed, and user empowerment through thoughtful use of space, typography, and interactive elements.

### Color Palette
**Primary Colors**:
- **Deep Slate**: #1a1a2e (Primary background, navigation)
- **Soft Blue**: #4a90e2 (Accent color, CTAs, active states)
- **Pure White**: #ffffff (Content backgrounds, text on dark)
- **Light Gray**: #f8f9fa (Secondary backgrounds, subtle divisions)

**Accent Colors**:
- **Success Green**: #28a745 (Online status, confirmations)
- **Warning Amber**: #ffc107 (Notifications, alerts)
- **Error Red**: #dc3545 (Errors, deletions)
- **Neutral Gray**: #6c757d (Secondary text, inactive states)

### Typography
**Primary Font**: Inter (Sans-serif)
- **Display Text**: 32px, font-weight: 700 (Page titles, major headings)
- **Heading Text**: 24px, font-weight: 600 (Section headers)
- **Body Text**: 16px, font-weight: 400 (Message content, descriptions)
- **Caption Text**: 14px, font-weight: 400 (Timestamps, metadata)
- **Button Text**: 16px, font-weight: 500 (Actions, labels)

**Secondary Font**: JetBrains Mono (Monospace)
- **Code/Tech Text**: 14px (Usernames, technical info)

## Visual Effects & Styling

### Background Treatment
**Liquid Glass Effect**: Subtle translucent overlays with backdrop blur
- **Navigation Bar**: 20% opacity with 10px blur
- **Modal Overlays**: 30% opacity with 15px blur
- **Floating Panels**: 25% opacity with 8px blur

### Interactive Elements
**Button Styles**:
- **Primary Button**: Soft blue background, white text, 8px border-radius
- **Secondary Button**: Transparent background, blue border, blue text
- **Icon Button**: Circular, 40px diameter, hover state with subtle glow

**Form Elements**:
- **Input Fields**: Light gray background, 6px border-radius, subtle shadow
- **Text Areas**: Expandable with auto-resize functionality
- **Dropdowns**: Clean list style with hover highlights

### Animation & Motion
**Micro-Interactions**:
- **Button Hover**: Subtle scale (1.02x) with soft shadow expansion
- **Message Send**: Slide-up animation with fade-in (200ms duration)
- **Loading States**: Pulsing skeleton screens with gradient shimmer
- **Transitions**: Smooth 300ms ease-in-out for all state changes

**Scroll Animations**:
- **Parallax Effect**: Subtle background movement (max 20px offset)
- **Reveal Animation**: Content slides up 20px with fade-in on scroll
- **Sticky Elements**: Navigation bar with backdrop blur on scroll

### Chat Interface Styling
**Message Bubbles**:
- **Sent Messages**: Blue gradient background, white text, 18px border-radius
- **Received Messages**: White background, dark text, subtle border
- **Media Messages**: Rounded corners with shadow, inline preview
- **System Messages**: Centered, gray text, italic styling

**Chat List**:
- **Active Chat**: Soft blue background with subtle glow
- **Unread Indicator**: Blue dot with white number badge
- **Online Status**: Green circle (8px) in bottom-right of avatar
- **Last Message**: Gray preview text with timestamp

### Media Gallery Design
**Grid Layout**:
- **Image Thumbnails**: 1:1 aspect ratio, rounded corners (8px)
- **Video Thumbnails**: Play button overlay, duration badge
- **File Icons**: Color-coded by type, size and name display
- **Hover States**: Zoom effect with overlay information

### Navigation Design
**Top Navigation**:
- **Logo/App Name**: Left-aligned with subtle animation on hover
- **Search Bar**: Centered, expandable with focus states
- **User Menu**: Right-aligned with avatar dropdown

**Bottom Navigation** (Mobile):
- **Tab Icons**: 24px icons with text labels
- **Active State**: Blue icon with subtle background highlight
- **Badge Indicators**: Red dots for notifications

## Layout & Spacing

### Grid System
**Desktop Layout**:
- **Sidebar**: 300px width (chat list, contacts)
- **Main Content**: Flexible width (chat interface)
- **Right Panel**: 280px width (media gallery, info)

**Mobile Layout**:
- **Full Width**: Single column with bottom navigation
- **Modal Overlays**: Full-screen with slide-up animations

### Spacing Scale
- **XS**: 4px (tight spacing)
- **SM**: 8px (component padding)
- **MD**: 16px (section spacing)
- **LG**: 24px (major divisions)
- **XL**: 32px (page margins)

### Responsive Breakpoints
- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px+

## Component Specifications

### Chat Input Area
- **Height**: 60px minimum, expands with content
- **Background**: White with subtle border
- **Elements**: Text area, emoji picker, attachment button, send button
- **Focus State**: Blue border with inner shadow

### Message Display
- **Bubble Padding**: 12px horizontal, 8px vertical
- **Margin**: 4px between messages, 16px between users
- **Timestamp**: 12px text, positioned below message
- **Status Icons**: 16px size, positioned right of timestamp

### Contact Cards
- **Size**: 72px height, full width
- **Avatar**: 48px circle with online status indicator
- **Content**: Name (16px), last message (14px), timestamp (12px)
- **Actions**: Swipe gestures for quick actions

### Modal Windows
- **Background**: White with 24px border-radius
- **Padding**: 32px all sides
- **Backdrop**: 50% opacity black with blur
- **Animation**: Scale-in from center (200ms)

## Accessibility Considerations
- **Contrast Ratios**: Minimum 4.5:1 for all text
- **Focus Indicators**: Clear blue outline (2px) on all interactive elements
- **Touch Targets**: Minimum 44px for mobile interactions
- **Color Independence**: No information conveyed by color alone
- **Screen Reader**: Proper ARIA labels and semantic HTML structure