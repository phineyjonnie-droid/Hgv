// TeleConnect Messaging App - Main JavaScript
// Comprehensive functionality for chat, media, contacts, and settings

class TeleConnectApp {
    constructor() {
        this.currentPage = this.getCurrentPage();
        this.messages = [];
        this.contacts = [];
        this.mediaItems = [];
        this.settings = this.loadSettings();
        this.init();
    }

    getCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('media.html')) return 'media';
        if (path.includes('contacts.html')) return 'contacts';
        if (path.includes('settings.html')) return 'settings';
        return 'chat';
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        
        switch (this.currentPage) {
            case 'chat':
                this.initChatPage();
                break;
            case 'media':
                this.initMediaPage();
                break;
            case 'contacts':
                this.initContactsPage();
                break;
            case 'settings':
                this.initSettingsPage();
                break;
        }
    }

    setupEventListeners() {
        // Global event listeners
        document.addEventListener('DOMContentLoaded', () => {
            this.initializeScrollReveal();
        });

        // Navigation menu
        const userMenu = document.getElementById('userMenu');
        if (userMenu) {
            userMenu.addEventListener('click', this.toggleUserMenu.bind(this));
        }

        // Theme switching
        this.setupThemeSwitching();
    }

    initializeAnimations() {
        // Initialize Anime.js animations
        if (typeof anime !== 'undefined') {
            this.setupPageAnimations();
        }
    }

    initializeScrollReveal() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.scroll-reveal').forEach(el => {
            observer.observe(el);
        });
    }

    setupPageAnimations() {
        // Animate navigation bar on load
        anime({
            targets: 'nav',
            translateY: [-50, 0],
            opacity: [0, 1],
            duration: 800,
            easing: 'easeOutExpo'
        });

        // Animate main content
        anime({
            targets: '.setting-card, .contact-card, .media-item',
            translateY: [30, 0],
            opacity: [0, 1],
            duration: 600,
            delay: anime.stagger(100),
            easing: 'easeOutExpo'
        });
    }

    // Chat Page Functionality
    initChatPage() {
        this.setupChatInterface();
        this.setupEmojiPicker();
        this.setupMessageInput();
        this.simulateRealTimeChat();
    }

    setupChatInterface() {
        const messageInput = document.getElementById('messageInput');
        const sendBtn = document.getElementById('sendBtn');
        const messagesArea = document.getElementById('messagesArea');

        if (sendBtn && messageInput) {
            sendBtn.addEventListener('click', this.sendMessage.bind(this));
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });

            // Auto-resize textarea
            messageInput.addEventListener('input', () => {
                messageInput.style.height = 'auto';
                messageInput.style.height = Math.min(messageInput.scrollHeight, 100) + 'px';
            });
        }

        // Chat list interactions
        document.querySelectorAll('.chat-item').forEach(item => {
            item.addEventListener('click', () => {
                this.switchChat(item);
            });
        });
    }

    setupEmojiPicker() {
        const emojiBtn = document.getElementById('emojiBtn');
        const emojiModal = document.getElementById('emojiModal');
        const closeEmoji = document.getElementById('closeEmoji');

        if (emojiBtn && emojiModal) {
            emojiBtn.addEventListener('click', () => {
                emojiModal.classList.remove('hidden');
                this.animateModal(emojiModal);
            });

            closeEmoji?.addEventListener('click', () => {
                emojiModal.classList.add('hidden');
            });

            // Emoji selection
            document.querySelectorAll('.emoji-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const emoji = e.target.textContent;
                    this.insertEmoji(emoji);
                });
            });
        }
    }

    insertEmoji(emoji) {
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            const cursorPos = messageInput.selectionStart;
            const textBefore = messageInput.value.substring(0, cursorPos);
            const textAfter = messageInput.value.substring(cursorPos);
            messageInput.value = textBefore + emoji + textAfter;
            messageInput.focus();
            messageInput.setSelectionRange(cursorPos + emoji.length, cursorPos + emoji.length);
        }
    }

    setupMessageInput() {
        const attachmentBtn = document.getElementById('attachmentBtn');
        const voiceBtn = document.getElementById('voiceBtn');

        attachmentBtn?.addEventListener('click', () => {
            this.showAttachmentOptions();
        });

        voiceBtn?.addEventListener('click', () => {
            this.toggleVoiceRecording();
        });
    }

    sendMessage() {
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();

        if (message) {
            this.addMessage(message, 'sent');
            messageInput.value = '';
            messageInput.style.height = 'auto';
            
            // Simulate typing indicator and response
            setTimeout(() => {
                this.showTypingIndicator();
            }, 1000);

            setTimeout(() => {
                this.hideTypingIndicator();
                this.addMessage('Thanks for your message! This is a demo response.', 'received');
            }, 3000);
        }
    }

    addMessage(content, type) {
        const messagesArea = document.getElementById('messagesArea');
        if (!messagesArea) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type} flex items-start space-x-3 ${type === 'sent' ? 'justify-end' : ''}`;

        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        if (type === 'received') {
            messageDiv.innerHTML = `
                <img src="resources/avatars.png" alt="Sarah" class="w-8 h-8 rounded-full object-cover">
                <div class="message-received max-w-xs px-4 py-2 rounded-2xl">
                    <p class="text-sm text-gray-800">${content}</p>
                    <div class="flex items-center justify-between mt-1">
                        <span class="text-xs text-gray-500">${timestamp}</span>
                        <div class="flex space-x-1">
                            <button class="text-gray-400 hover:text-gray-600 reaction-btn">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h.01M15 14h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        } else {
            messageDiv.innerHTML = `
                <div class="message-sent max-w-xs px-4 py-2 rounded-2xl text-white">
                    <p class="text-sm">${content}</p>
                    <div class="flex items-center justify-between mt-1">
                        <span class="text-xs text-blue-100">${timestamp}</span>
                        <svg class="w-4 h-4 text-blue-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                </div>
            `;
        }

        messagesArea.appendChild(messageDiv);
        this.scrollToBottom();

        // Animate message appearance
        anime({
            targets: messageDiv,
            translateY: [30, 0],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutExpo'
        });
    }

    showTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.classList.remove('hidden');
        }
    }

    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.classList.add('hidden');
        }
    }

    scrollToBottom() {
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }
    }

    switchChat(chatItem) {
        // Remove active class from all chat items
        document.querySelectorAll('.chat-item').forEach(item => {
            item.classList.remove('active', 'bg-blue-50', 'border-l-4', 'border-blue-500');
        });

        // Add active class to clicked item
        chatItem.classList.add('active', 'bg-blue-50', 'border-l-4', 'border-blue-500');

        // Update chat header
        const chatName = chatItem.querySelector('h3').textContent;
        const chatHeader = document.querySelector('.bg-white.border-b h2');
        if (chatHeader) {
            chatHeader.textContent = chatName;
        }

        // Clear messages and load new ones (simulation)
        this.clearMessages();
        this.loadChatMessages(chatName);
    }

    clearMessages() {
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            // Keep date divider, remove messages
            const dateDivider = messagesArea.querySelector('.flex.items-center.justify-center');
            messagesArea.innerHTML = '';
            if (dateDivider) {
                messagesArea.appendChild(dateDivider);
            }
        }
    }

    loadChatMessages(chatName) {
        // Simulate loading different chat messages
        const sampleMessages = {
            'Sarah Johnson': [
                { content: 'Hi Alex! How are you doing today?', type: 'received' },
                { content: 'Hey Sarah! I am doing great, thanks for asking.', type: 'sent' }
            ],
            'Mike Chen': [
                { content: 'Are we still meeting tomorrow?', type: 'received' },
                { content: 'Yes, same time and place!', type: 'sent' }
            ]
        };

        const messages = sampleMessages[chatName] || [];
        messages.forEach(msg => {
            setTimeout(() => {
                this.addMessage(msg.content, msg.type);
            }, Math.random() * 1000);
        });
    }

    simulateRealTimeChat() {
        // Simulate occasional incoming messages
        setInterval(() => {
            if (Math.random() < 0.1) { // 10% chance every interval
                this.showTypingIndicator();
                setTimeout(() => {
                    this.hideTypingIndicator();
                    const responses = [
                        'That sounds great!',
                        'I agree with your point.',
                        'Let me think about that.',
                        'Thanks for sharing!',
                        'I will get back to you soon.'
                    ];
                    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                    this.addMessage(randomResponse, 'received');
                }, 2000);
            }
        }, 10000);
    }

    // Media Page Functionality
    initMediaPage() {
        this.setupMediaUpload();
        this.setupMediaFilters();
        this.setupMediaSearch();
        this.initializeStorageChart();
    }

    setupMediaUpload() {
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        const browseBtn = document.getElementById('browseBtn');

        if (uploadZone && fileInput) {
            browseBtn?.addEventListener('click', () => fileInput.click());

            uploadZone.addEventListener('click', () => fileInput.click());

            uploadZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadZone.classList.add('dragover');
            });

            uploadZone.addEventListener('dragleave', () => {
                uploadZone.classList.remove('dragover');
            });

            uploadZone.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadZone.classList.remove('dragover');
                this.handleFileUpload(e.dataTransfer.files);
            });

            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target.files);
            });
        }
    }

    handleFileUpload(files) {
        const uploadProgress = document.getElementById('uploadProgress');
        const progressBar = document.getElementById('progressBar');
        const progressText = document.getElementById('progressText');

        if (uploadProgress) {
            uploadProgress.classList.remove('hidden');
            
            let progress = 0;
            const interval = setInterval(() => {
                progress += Math.random() * 10;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(interval);
                    setTimeout(() => {
                        uploadProgress.classList.add('hidden');
                        this.addUploadedFiles(files);
                    }, 500);
                }
                
                if (progressBar) progressBar.style.width = progress + '%';
                if (progressText) progressText.textContent = Math.round(progress) + '%';
            }, 200);
        }
    }

    addUploadedFiles(files) {
        Array.from(files).forEach(file => {
            const mediaItem = this.createMediaItem({
                name: file.name,
                size: this.formatFileSize(file.size),
                type: file.type.split('/')[0],
                date: new Date().toISOString().split('T')[0]
            });
            
            const gallery = document.getElementById('mediaGallery');
            if (gallery) {
                gallery.insertBefore(mediaItem, gallery.firstChild);
                
                // Animate new item
                anime({
                    targets: mediaItem,
                    scale: [0.8, 1],
                    opacity: [0, 1],
                    duration: 500,
                    easing: 'easeOutExpo'
                });
            }
        });
    }

    createMediaItem(file) {
        const div = document.createElement('div');
        div.className = 'media-item bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden cursor-pointer';
        div.dataset.type = file.type;
        div.dataset.name = file.name;
        div.dataset.size = file.size;
        div.dataset.date = file.date;

        const typeColors = {
            image: 'bg-blue-500',
            video: 'bg-purple-500',
            audio: 'bg-green-500',
            application: 'bg-red-500'
        };

        const typeLabels = {
            image: 'Image',
            video: 'Video',
            audio: 'Audio',
            application: 'Document'
        };

        div.innerHTML = `
            <div class="h-48 ${typeColors[file.type] || 'bg-gray-500'} flex items-center justify-center">
                <svg class="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
            </div>
            <div class="p-3">
                <h3 class="font-medium text-gray-900 text-sm truncate">${file.name}</h3>
                <p class="text-xs text-gray-500 mt-1">${file.size} • ${file.date}</p>
                <div class="flex items-center justify-between mt-2">
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-${typeColors[file.type]?.replace('bg-', '') || 'gray'}-100 text-${typeColors[file.type]?.replace('bg-', '') || 'gray'}-800">${typeLabels[file.type] || 'File'}</span>
                    <div class="flex space-x-1">
                        <button class="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                            </svg>
                        </button>
                        <button class="p-1 text-gray-400 hover:text-red-600 transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;

        return div;
    }

    setupMediaFilters() {
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                // Update active filter
                document.querySelectorAll('.filter-btn').forEach(b => {
                    b.classList.remove('active', 'bg-blue-500', 'text-white');
                    b.classList.add('bg-gray-100', 'text-gray-700');
                });
                
                e.target.classList.add('active', 'bg-blue-500', 'text-white');
                e.target.classList.remove('bg-gray-100', 'text-gray-700');
                
                const filter = e.target.dataset.filter;
                this.filterMedia(filter);
            });
        });
    }

    filterMedia(filter) {
        const mediaItems = document.querySelectorAll('.media-item');
        mediaItems.forEach(item => {
            const itemType = item.dataset.type;
            if (filter === 'all' || itemType === filter || 
                (filter === 'documents' && itemType === 'application')) {
                item.style.display = 'block';
                anime({
                    targets: item,
                    opacity: [0, 1],
                    scale: [0.8, 1],
                    duration: 300,
                    easing: 'easeOutExpo'
                });
            } else {
                anime({
                    targets: item,
                    opacity: [1, 0],
                    scale: [1, 0.8],
                    duration: 200,
                    easing: 'easeInExpo',
                    complete: () => {
                        item.style.display = 'none';
                    }
                });
            }
        });
    }

    setupMediaSearch() {
        const searchInput = document.getElementById('mediaSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase();
                this.searchMedia(query);
            });
        }
    }

    searchMedia(query) {
        const mediaItems = document.querySelectorAll('.media-item');
        mediaItems.forEach(item => {
            const name = item.dataset.name.toLowerCase();
            const matches = name.includes(query);
            
            if (matches || query === '') {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }

    initializeStorageChart() {
        const chartElement = document.getElementById('storageChart');
        if (chartElement && typeof echarts !== 'undefined') {
            const chart = echarts.init(chartElement);
            
            const option = {
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b}: {c} MB ({d}%)'
                },
                series: [{
                    name: 'Storage Usage',
                    type: 'pie',
                    radius: ['40%', '70%'],
                    center: ['50%', '50%'],
                    data: [
                        { value: 1200, name: 'Images', itemStyle: { color: '#3b82f6' } },
                        { value: 800, name: 'Videos', itemStyle: { color: '#8b5cf6' } },
                        { value: 400, name: 'Documents', itemStyle: { color: '#10b981' } },
                        { value: 100, name: 'Audio', itemStyle: { color: '#f59e0b' } }
                    ],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }]
            };
            
            chart.setOption(option);
        }
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Contacts Page Functionality
    initContactsPage() {
        this.setupContactSearch();
        this.setupContactFilters();
        this.setupContactActions();
    }

    setupContactSearch() {
        const searchInput = document.getElementById('contactSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase();
                this.searchContacts(query);
            });
        }
    }

    searchContacts(query) {
        const contactCards = document.querySelectorAll('.contact-card');
        contactCards.forEach(card => {
            const name = card.querySelector('h3').textContent.toLowerCase();
            const matches = name.includes(query);
            
            if (matches || query === '') {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    setupContactFilters() {
        const statusFilter = document.getElementById('statusFilter');
        const groupFilter = document.getElementById('groupFilter');

        statusFilter?.addEventListener('change', () => this.applyContactFilters());
        groupFilter?.addEventListener('change', () => this.applyContactFilters());
    }

    applyContactFilters() {
        const statusFilter = document.getElementById('statusFilter')?.value || 'all';
        const groupFilter = document.getElementById('groupFilter')?.value || 'all';

        const contactCards = document.querySelectorAll('.contact-card');
        contactCards.forEach(card => {
            const status = card.dataset.status;
            const groups = card.dataset.groups;

            const statusMatch = statusFilter === 'all' || status === statusFilter;
            const groupMatch = groupFilter === 'all' || groups.includes(groupFilter);

            if (statusMatch && groupMatch) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    setupContactActions() {
        // Add contact modal
        const newContactBtn = document.getElementById('newContact');
        const addContactModal = document.getElementById('addContactModal');
        const closeAddContact = document.getElementById('closeAddContact');
        const cancelAddContact = document.getElementById('cancelAddContact');
        const addContactForm = document.getElementById('addContactForm');

        newContactBtn?.addEventListener('click', () => {
            addContactModal?.classList.remove('hidden');
            this.animateModal(addContactModal);
        });

        closeAddContact?.addEventListener('click', () => {
            addContactModal?.classList.add('hidden');
        });

        cancelAddContact?.addEventListener('click', () => {
            addContactModal?.classList.add('hidden');
        });

        addContactForm?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.addNewContact();
            addContactModal?.classList.add('hidden');
        });

        // Contact card interactions
        document.querySelectorAll('.contact-card button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = btn.querySelector('svg')?.getAttribute('stroke') === 'currentColor' ? 
                    (btn.closest('svg')?.innerHTML.includes('M8 12h') ? 'message' : 'call') : 'message';
                this.handleContactAction(action);
            });
        });
    }

    addNewContact() {
        const name = document.getElementById('contactName')?.value;
        const phone = document.getElementById('contactPhone')?.value;
        const email = document.getElementById('contactEmail')?.value;
        const group = document.getElementById('contactGroup')?.value;

        if (name) {
            const contactCard = this.createContactCard({
                name,
                phone,
                email,
                group,
                status: 'offline',
                recent: new Date().toISOString().split('T')[0]
            });

            const contactsGrid = document.getElementById('contactsGrid');
            if (contactsGrid) {
                contactsGrid.insertBefore(contactCard, contactsGrid.firstChild);
                
                // Animate new contact
                anime({
                    targets: contactCard,
                    scale: [0.8, 1],
                    opacity: [0, 1],
                    duration: 500,
                    easing: 'easeOutExpo'
                });
            }

            // Reset form
            document.getElementById('addContactForm')?.reset();
        }
    }

    createContactCard(contact) {
        const div = document.createElement('div');
        div.className = 'contact-card bg-white rounded-lg shadow-sm border border-gray-200 p-4 cursor-pointer';
        div.dataset.status = contact.status;
        div.dataset.groups = contact.group || '';
        div.dataset.recent = contact.recent;

        const statusColors = {
            online: 'bg-green-500',
            away: 'bg-yellow-500',
            offline: 'bg-gray-500'
        };

        const groupColors = {
            team: 'bg-blue-100 text-blue-800',
            friends: 'bg-purple-100 text-purple-800',
            family: 'bg-orange-100 text-orange-800',
            work: 'bg-green-100 text-green-800'
        };

        div.innerHTML = `
            <div class="flex items-start space-x-3">
                <div class="relative">
                    <img src="resources/avatars.png" alt="${contact.name}" class="w-12 h-12 rounded-full object-cover">
                    <div class="absolute -bottom-1 -right-1 w-4 h-4 ${statusColors[contact.status]} border-2 border-white rounded-full"></div>
                </div>
                <div class="flex-1 min-w-0">
                    <h3 class="font-semibold text-gray-900 text-sm truncate">${contact.name}</h3>
                    <p class="text-xs text-gray-500 truncate">${contact.phone || contact.email || 'No contact info'}</p>
                    ${contact.group ? `<div class="flex items-center mt-1">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${groupColors[contact.group] || 'bg-gray-100 text-gray-800'}">${contact.group}</span>
                    </div>` : ''}
                    <div class="flex items-center justify-between mt-2">
                        <span class="text-xs text-gray-400">Just added</span>
                        <div class="flex space-x-1">
                            <button class="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                </svg>
                            </button>
                            <button class="p-1 text-gray-400 hover:text-green-600 transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        return div;
    }

    handleContactAction(action) {
        switch (action) {
            case 'message':
                this.showNotification('Opening chat...', 'info');
                break;
            case 'call':
                this.showNotification('Calling...', 'info');
                break;
        }
    }

    // Settings Page Functionality
    initSettingsPage() {
        this.setupSettingsTabs();
        this.setupToggleSwitches();
        this.setupThemeCustomization();
        this.loadSettingsValues();
    }

    setupSettingsTabs() {
        document.querySelectorAll('.settings-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.target.dataset.tab;
                this.switchSettingsTab(tabName);
            });
        });
    }

    switchSettingsTab(tabName) {
        // Update tab appearance
        document.querySelectorAll('.settings-tab').forEach(tab => {
            tab.classList.remove('active', 'bg-blue-500', 'text-white');
            tab.classList.add('bg-gray-100', 'text-gray-700');
        });
        
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active', 'bg-blue-500', 'text-white');
        document.querySelector(`[data-tab="${tabName}"]`).classList.remove('bg-gray-100', 'text-gray-700');

        // Show corresponding content
        document.querySelectorAll('.settings-content').forEach(content => {
            content.classList.add('hidden');
        });
        
        document.getElementById(`${tabName}-settings`).classList.remove('hidden');
    }

    setupToggleSwitches() {
        document.querySelectorAll('.toggle-switch').forEach(toggle => {
            toggle.addEventListener('click', () => {
                toggle.classList.toggle('active');
                const setting = toggle.dataset.setting;
                const value = toggle.classList.contains('active');
                this.updateSetting(setting, value);
            });
        });
    }

    setupThemeCustomization() {
        // Theme selection
        document.querySelectorAll('.theme-preview').forEach(theme => {
            theme.addEventListener('click', () => {
                document.querySelectorAll('.theme-preview').forEach(t => {
                    t.classList.remove('selected');
                });
                theme.classList.add('selected');
                
                const themeName = theme.dataset.theme;
                this.updateTheme(themeName);
            });
        });

        // Color picker
        document.querySelectorAll('.color-picker').forEach(picker => {
            picker.addEventListener('click', () => {
                document.querySelectorAll('.color-picker').forEach(p => {
                    p.classList.remove('selected');
                });
                picker.classList.add('selected');
                
                const color = picker.dataset.color;
                this.updateAccentColor(color);
            });
        });
    }

    updateTheme(themeName) {
        document.body.classList.remove('theme-light', 'theme-dark');
        document.body.classList.add(`theme-${themeName}`);
        this.updateSetting('theme', themeName);
    }

    updateAccentColor(color) {
        document.documentElement.style.setProperty('--accent-color', `var(--color-${color})`);
        this.updateSetting('accentColor', color);
    }

    updateSetting(key, value) {
        this.settings[key] = value;
        this.saveSettings();
    }

    loadSettings() {
        const saved = localStorage.getItem('teleconnect-settings');
        return saved ? JSON.parse(saved) : {
            theme: 'light',
            accentColor: 'blue',
            showNotifications: true,
            soundAlerts: true,
            readReceipts: true,
            typingIndicators: true
        };
    }

    saveSettings() {
        localStorage.setItem('teleconnect-settings', JSON.stringify(this.settings));
    }

    loadSettingsValues() {
        // Apply saved settings to UI
        Object.keys(this.settings).forEach(key => {
            const toggle = document.querySelector(`[data-setting="${key}"]`);
            if (toggle && typeof this.settings[key] === 'boolean') {
                if (this.settings[key]) {
                    toggle.classList.add('active');
                } else {
                    toggle.classList.remove('active');
                }
            }
        });
    }

    // Utility Functions
    animateModal(modal) {
        if (modal && typeof anime !== 'undefined') {
            const content = modal.querySelector('.bg-white');
            anime({
                targets: content,
                scale: [0.8, 1],
                opacity: [0, 1],
                duration: 300,
                easing: 'easeOutExpo'
            });
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-20 right-6 z-50 px-6 py-3 rounded-lg shadow-lg text-white ${
            type === 'success' ? 'bg-green-500' : 
            type === 'error' ? 'bg-red-500' : 
            type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
        }`;
        notification.textContent = message;

        document.body.appendChild(notification);

        // Animate in
        anime({
            targets: notification,
            translateX: [300, 0],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutExpo'
        });

        // Remove after 3 seconds
        setTimeout(() => {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 300,
                easing: 'easeInExpo',
                complete: () => {
                    notification.remove();
                }
            });
        }, 3000);
    }

    toggleUserMenu() {
        this.showNotification('User menu functionality coming soon!', 'info');
    }

    showAttachmentOptions() {
        this.showNotification('File attachment feature coming soon!', 'info');
    }

    toggleVoiceRecording() {
        this.showNotification('Voice recording feature coming soon!', 'info');
    }

    setupThemeSwitching() {
        // Apply saved theme on load
        if (this.settings.theme) {
            document.body.classList.add(`theme-${this.settings.theme}`);
        }
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TeleConnectApp();
});

// Handle page visibility changes for real-time features
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Page is hidden, pause real-time features
        console.log('App paused');
    } else {
        // Page is visible, resume real-time features
        console.log('App resumed');
    }
});

// Handle online/offline status
window.addEventListener('online', () => {
    console.log('App is online');
});

window.addEventListener('offline', () => {
    console.log('App is offline');
});